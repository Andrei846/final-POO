﻿using System;

public class VagaEstacionamento
{

    private readonly int _numeroVaga;
    private bool _ocupada;
    private string _tipoVeiculo;

    public int NumeroVaga => _numeroVaga;
    public bool Ocupada => _ocupada; 
    public string TipoVeiculo
    {
        get => _tipoVeiculo;
        private set
        {
         
            if (value == "Carro" || value == "Moto" || value == "Caminhão")
            {
                _tipoVeiculo = value;
            }
            else
            {
                throw new ArgumentException("Tipo de veículo inválido. Aceito: 'Carro', 'Moto' ou 'Caminhão'.");
            }
        }
    }

   
    public VagaEstacionamento(int numeroVaga, string tipoVeiculo)
    {
        _numeroVaga = numeroVaga;
        TipoVeiculo = tipoVeiculo;  
        _ocupada = false; 
    }

 
    public void OcuparVaga()
    {
        if (!_ocupada)
        {
            _ocupada = true;
            Console.WriteLine($"A vaga {_numeroVaga} foi ocupada.");
        }
        else
        {
            Console.WriteLine($"A vaga {_numeroVaga} já está ocupada.");
        }
    }

    public void LiberarVaga()
    {
        if (_ocupada)
        {
            _ocupada = false;
            Console.WriteLine($"A vaga {_numeroVaga} foi liberada.");
        }
        else
        {
            Console.WriteLine($"A vaga {_numeroVaga} já está livre.");
        }
    }

  
    public void AlterarTipoVeiculo(string novoTipo)
    {
        if (!_ocupada)
        {
            TipoVeiculo = novoTipo;
            Console.WriteLine($"O tipo de veículo da vaga {_numeroVaga} foi alterado para: {novoTipo}.");
        }
        else
        {
            Console.WriteLine($"Não é possível alterar o tipo de veículo da vaga {_numeroVaga} porque ela está ocupada.");
        }
    }

   
    public void ExibirInformacoes()
    {
        string status = _ocupada ? "Ocupada" : "Livre";
        Console.WriteLine($"Número da Vaga: {_numeroVaga}");
        Console.WriteLine($"Tipo de Veículo Permitido: {_tipoVeiculo}");
        Console.WriteLine($"Status da Vaga: {status}");
    }
}