﻿class Program
{
    static void Main(string[] args)
    {
        Produto produto = new Produto("Camiseta", 29.99m);
        produto.AdicionarEstoque(50); 

        Console.WriteLine($"Quantidade total em estoque: {produto.QuantidadeTotal}");
        Console.WriteLine($"Valor total em estoque: R${produto.ValorTotalEmEstoque()}");

        produto.RemoverEstoque(20);  
        Console.WriteLine($"Quantidade total em estoque após remoção: {produto.QuantidadeTotal}");
        Console.WriteLine($"Valor total em estoque após remoção: R${produto.ValorTotalEmEstoque()}");
    }
}