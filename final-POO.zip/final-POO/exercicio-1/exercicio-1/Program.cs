﻿public class Produto
{
 
    private string _nome;
    private decimal _preco;
    private int _quantidade;
    private int _quantidadeTotal;

    
    public string Nome
    {
        get { return _nome; }
        set { _nome = value; }
    }

    public decimal Preco
    {
        get { return _preco; }
        set { _preco = value; }
    }

    
    public int Quantidade
    {
        set { _quantidade = value; }
    }

   
    public int QuantidadeTotal
    {
        get { return _quantidadeTotal; }
    }

 
    public Produto(string nome, decimal preco)
    {
        _nome = nome;
        _preco = preco;
        _quantidadeTotal = 0; 
    }


    public void AdicionarEstoque(int qtde)
    {
        if (qtde > 0)
        {
            _quantidadeTotal += qtde;
        }
    }

   
    public void RemoverEstoque(int qtde)
    {
        if (qtde > 0 && qtde <= _quantidadeTotal)
        {
            _quantidadeTotal -= qtde;
        }
        else
        {
            throw new InvalidOperationException("Quantidade insuficiente em estoque para remover.");
        }
    }

 
    public decimal ValorTotalEmEstoque()
    {
        return _preco * _quantidadeTotal;
    }
}